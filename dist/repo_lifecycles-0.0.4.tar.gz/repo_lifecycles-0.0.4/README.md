small library to quickly get by-commit software repository history to facilitate modeling of project lifecycles.

there are other vcs analysis tools. this is indended to be:
- a lightweight, minimum viable data collection tool 
- support longitudinal data collection out of the box 

installation:

```
pip install repo_lifecycles
```